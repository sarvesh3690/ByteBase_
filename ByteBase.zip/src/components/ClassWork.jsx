import React, { useEffect, useState } from "react";
import { Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Button, Paper } from "@mui/material";
import Sidebar from "./SideBar";
import axios from "axios";

function ClassWork() {
    const [assignments, setAssignments] = useState([]);

    const fetchAssignments = async () => {
        try {
            const response = await axios.get("http://localhost:8080/classwork");
            if (response.status == 200) {
                console.log(response.data);
                setAssignments(response.data);
            }
        } catch (error) {
            console.error("Error fetching classwork:", error);
        }
    };

    // Trigger fetch when the component loads
    useEffect(() => {
        fetchAssignments();

    }, []);

    return (
        <div className="app"><Sidebar />

            <div className="main-content">
                <TableContainer component={Paper} sx={{ marginTop: "20px", maxWidth: "1000px" }}>
                    <Table>
                        <TableHead>
                            <TableRow sx={{ backgroundColor: "#b22222" }}>
                                <TableCell sx={{ color: "white", fontWeight: "bold" }}>Sr.No</TableCell>
                                <TableCell sx={{ color: "white", fontWeight: "bold" }}>Date</TableCell>
                                <TableCell sx={{ color: "white", fontWeight: "bold" }}>Topic Name</TableCell>
                                <TableCell sx={{ color: "white", fontWeight: "bold" }}>Module Name</TableCell>
                                <TableCell sx={{ color: "white", fontWeight: "bold" }}>Assignment</TableCell>
                            </TableRow>
                        </TableHead>
                        <TableBody>
                            {assignments.map((assignment, index) => (
                                <TableRow key={index}>
                                    <TableCell>{index + 1}</TableCell>
                                    <TableCell>{assignment.date}</TableCell>
                                    <TableCell>{assignment.topic}</TableCell>
                                    <TableCell>{assignment.module}</TableCell>
                                    <TableCell>
                                        <a
                                            href={assignment.zipFile.split('\\').pop()}
                                            download={assignment.zipFile.split('\\').pop()}
                                        >
                                            {assignment.zipFile.split('\\').pop()} {/* Display only the file name */}
                                        </a>
                                    </TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                </TableContainer>
            </div>
        </div>
    );
}

export default ClassWork;
