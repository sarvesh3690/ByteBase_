import React from "react";
import { Bar } from "react-chartjs-2";
import { Chart as ChartJS, CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend } from "chart.js";
import "../styles/App.css"
import Sidebar from "./SideBar";

ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend);

function Dashboard() {
  const user = localStorage.getItem("user");
  const data = {
    labels: ["Java", "Python", "C++", "JavaScript", "HTML"],
    datasets: [
      {
        label: "Proficiency Level",
        data: [80, 90, 70, 85, 95],
        backgroundColor: ["yellow", "cyan", "green", "pink", "purple"],
      },
    ],
  };

  const options = {
    responsive: true,
    plugins: {
      legend: { position: "top" },
      title: { display: true, text: "Static Proficiency Levels" },
    },
  };

  return (
    <>
      <div className="app"><Sidebar />

        <div className="main-content">
          <div>
            <h1>Welcome, Student</h1>
            <div className="student-info">
              <p><strong>Name:</strong> Byte Base</p>
              <p><strong>PNR:</strong> 123445566</p>
            </div>
          </div>
          <Bar data={data} options={options} />
        </div>
      </div>
    </>
  );
}

export default Dashboard;
