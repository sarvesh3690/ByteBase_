import React, { useState, useRef } from "react";
import { Box, Button, TextField } from "@mui/material";
import Editor from "@monaco-editor/react";
import { Col, Container, Row } from "react-bootstrap";
import axios from "axios";
import Sidebar from "./SideBar";
import "../styles/App.css";

export default function Marie() {
    const [text, setText] = useState("Output");

    const editorRef = useRef(null);

    function handleEditorDidMount(editor, monaco) {
        editorRef.current = editor;
    }

    async function getCode() {
        const code = editorRef.current.getValue()
        try {
            const response = await axios.post("http://127.0.0.1:9800/editor", code, {
                headers: {
                    'Accept': "*/*",
                    'Content-Type': 'text/plain'
                }
            });

            console.log('Server response:', response.data);
            // Update text state to show server response or any message
            setText(response.data.msg || "Server responded");
        } catch (error) {
            console.error('Error sending code:', error);
            setText('Error occurred while sending code.');
        }
    }



    return (
        <div className="app"><Sidebar />

        <div className="main-content">
        <Container fluid>
            <Row className="vh-100">
                {/* Main Content */}
                <Col sm={12} className="d-flex flex-column">
                    {/* Editor */}
                    <Row className="flex-grow-1 mt-3">
                        <Col sm={12}>
                            <Box
                                sx={{
                                    width: "75vw",
                                    height: "70vh", // Adjust as needed
                                    border: "1px solid #ccc",
                                    borderRadius: "8px",
                                    overflow: "hidden",
                                }}
                            >
                                <Editor
                                    height="100%"
                                    width="100%"
                                    theme="vs-dark"
                                    language="java"
                                    onMount={handleEditorDidMount}
                                    options={{
                                        scrollBeyondLastLine: false,
                                        fontSize: "18px",
                                    }}
                                />
                            </Box>
                        </Col>
                    </Row>

                    {/* Output Field */}
                    <Row className="mt-4">
                        <Col sm={12}>
                            <TextField
                                id="compiled"
                                multiline
                                rows={4}
                                fullWidth
                                value={text}
                                disabled
                                sx={{
                                    marginTop: "20px",
                                    bgcolor: "#f5f5f5",
                                    color:"#212121",
                                    border: "1px solid #ddd",
                                    borderRadius: "4px",
                                }}
                            />
                        </Col>
                    </Row>

                    {/* Buttons */}
                    <Row className="mt-3">
                        <Col sm={12} className="d-flex justify-content-end" style={{ marginTop: "10px", marginLeft: "5px" }}>
                            <Button
                                variant="contained"
                                color="success"
                                className="me-3"
                                onClick={() => getCode()}
                            >
                                Run
                            </Button>
                            <Button variant="contained" color="success">
                                Compile
                            </Button>
                        </Col>
                    </Row>
                </Col>
            </Row>
        </Container>
        </div>
        </div>
    );
}
