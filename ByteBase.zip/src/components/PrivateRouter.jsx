import { Navigate, Outlet } from "react-router-dom";


export function PrivateRouter(props) {
    const token = localStorage.getItem("user");
    if (token) {
        return (
            <>
                <Outlet />
            </>
        )
    }
    else {
        return (
            <Navigate to="/"></Navigate>
        )
    }
}