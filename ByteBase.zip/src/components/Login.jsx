import React, { useState } from "react";
import { TextField, Box, Typography, Button } from "@mui/material";
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

export default function EmailInput() {
    const [email, setEmail] = useState("");
    const [error, setError] = useState(false);
    const navigate = useNavigate();

    const handleEmailChange = (e) => {
        const value = e.target.value;
        setEmail(value);

        // Email validation regex
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(value)) {
            setError(true);
        } else {
            setError(false);
        }
    };

    const handleLogin = async () => {
        if (!error && email) {
            const response = await axios.post("http://127.0.0.1:9800/", { email }, {
                headers:{
                    'Content-Type':'application/json'
                },
                withCredentials:true
            })
            console.log(response)
            if (response.status == 200) {
                navigate("/otpverify");
            }
            if(response.status == 201){
                navigate("/passwordverify"); 
            }
            if (response.status == 204) {

                setError(true);
            }

        } else {
            alert("Please enter a valid email.");
        }
    };

    return (
        <Box
            sx={{
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                justifyContent: "center",
                width: "20vw",
                height: "30vh",
                padding: "16px",
                marginLeft: "35vw",
                backgroundColor: "#f5f5f5",
            }}
        >
            <Typography variant="h5" 
            sx={{
                color:"black"
            }}
            mb={2}>
                Login
            </Typography>
            <TextField
                label="Email"
                variant="outlined"
                fullWidth
                error={error}
                helperText={error ? "Please enter a valid email address." : ""}
                value={email}
                onChange={handleEmailChange}
                sx={{
                    maxWidth: "400px",
                    marginBottom: "16px",
                }}
            />
            <Button
                variant="contained"
                color="success"
                onClick={handleLogin}
                sx={{
                    maxWidth: "400px",
                    width: "100%", // Ensures the button matches the width of the input field
                    marginTop: "8px",
                }}
            >
                Login
            </Button>
        </Box>
    );
}
