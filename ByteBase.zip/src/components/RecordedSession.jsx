import { Box } from "@mui/material";
import { Container, Row } from "react-bootstrap";
import Sidebar from "./SideBar";
import { useEffect, useState } from "react";
import axios from "axios";

export default function RecordedSession() {
    const [videos, setVideos] = useState([]); // State to hold video details

    const fetchRecording = async () => {
        try {
            const response = await axios.get("http://localhost:8080/recording");
            if (response.status === 200) {
                setVideos(response.data);
            }
        } catch (error) {
            console.error("Error fetching assignments:", error);
        }
    };

    useEffect(() => {
        fetchRecording();

    }, []);



    return (
        <>
            <div className="app">
                <Sidebar />

                <div className="main-content">
                    <Container fluid>
                        <Row className="mt-1">
                            {/* Main Content */}
                            <Box
                                sx={{
                                    marginLeft: "250px",
                                    padding: "16px",
                                    height: "90vh", // Fixed height for the container
                                    overflowY: "auto", // Enables scrolling for the content inside
                                    width: "55vw",
                                    borderRadius: "8px",
                                    backgroundColor: "black", // Light background
                                }}
                                className="scroll-hidden"
                            >


                                {/* Video Boxes */}
                                {videos.map((item, index) => (
                                    <Box
                                        key={index}
                                        sx={{
                                            height: "50vh", // Fixed height for each video box
                                            backgroundColor: "#fbc02d",
                                            border: "1px solid #ccc",
                                            borderRadius: "8px",
                                            padding: "16px",
                                            marginBottom: "16px",
                                            display: "flex",
                                            flexDirection: "column",
                                            justifyContent: "space-between",
                                            alignItems: "center",
                                        }}
                                    >
                                        {/* Topic */}
                                        <h3 style={{ color: "black", marginBottom: "8px" }}>{item.topic}</h3>

                                        {/* Additional Info */}
                                        <p style={{ color: "black" }}>
                                            Faculty: {item.faculty} | Module: {item.moduleName} | Date: {item.createdOn}
                                        </p>

                                        {/* Render video or iframe */}
                                        <iframe
                                            src={item.link}
                                            width="100%"
                                            height="80%"
                                            style={{
                                                borderRadius: "8px",
                                                border: "none",
                                            }}
                                            allowFullScreen
                                        ></iframe>
                                    </Box>
                                ))}
                            </Box>
                        </Row>
                    </Container>
                </div>
            </div>
            <style jsx>{`
                .scroll-hidden {
                    scrollbar-width: none; /* For Firefox */
                    -ms-overflow-style: none; /* For Internet Explorer and Edge */
                }

                .scroll-hidden::-webkit-scrollbar {
                    display: none; /* For Chrome, Safari, and Opera */
                }
            `}</style>
        </>
    );
}
