import React, { useState } from "react";
import { TextField, Box, Typography, Button } from "@mui/material";
import axios from "axios";
import { useNavigate } from "react-router-dom";

export default function AddPassword() {
    const [password, setPassword] = useState("");
    const [confirmPassword, setConfirmPassword] = useState("");
    const [error, setError] = useState("");
    const navigate = useNavigate();

    const handlePasswordChange = (e) => {
        setPassword(e.target.value);
    };

    const handleConfirmPasswordChange = (e) => {
        setConfirmPassword(e.target.value);
    };

    const handleVerify = async () => {
        if (password === confirmPassword) {
            const response = await axios.post("http://127.0.0.1:9800/addpassword", { password }, {
                headers: {
                    'Content-Type': 'application/json'
                },
                withCredentials: true
            })
            if (response.status == 200) {
                localStorage.setItem("user", JSON.stringify(response.data.data1));
                navigate("/dashboard");
            }
        } else {
            setError("Passwords do not match!");
        }
    };

    return (
        <Box
            sx={{
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                justifyContent: "center",
                width: "20vw",
                height: "30vh",
                padding: "16px",
                marginLeft: "35vw",
                backgroundColor: "#f5f5f5",
            }}
        >
            <Typography variant="h5"
                sx={{
                    color: "black"
                }}
                mb={2}>
                Set Password
            </Typography>
            <TextField
                label="Password"
                type="password"
                variant="outlined"
                value={password}
                onChange={handlePasswordChange}
                sx={{ marginBottom: "16px", width: "300px" }}
            />
            <TextField
                label="Confirm Password"
                type="password"
                variant="outlined"
                value={confirmPassword}
                onChange={handleConfirmPasswordChange}
                sx={{ marginBottom: "16px", width: "300px" }}
                error={Boolean(error)}
                helperText={error}
            />
            <Button
                variant="contained"
                color="success"
                onClick={handleVerify}
                sx={{ width: "300px" }}
            >
                Set Password
            </Button>
        </Box>
    );
}
