import React, { useState } from "react";
import { TextField, Box, Typography, Button } from "@mui/material";
import axios from "axios";
import { useNavigate } from "react-router-dom";

export default function OtpVerification() {
    const [otp, setOtp] = useState("");
    const [error, setError] = useState(false);
    const navigate = useNavigate();

    const handleOtpChange = (e) => {
        const value = e.target.value;

        // Allow only digits and limit to 4 characters
        if (/^\d{0,4}$/.test(value)) {
            setOtp(value);

            // Validate OTP length
            setError(value.length !== 4);
        }
    };

    const handleVerify = async () => {

        if (!error && otp.length === 4) {
            const response = await axios.post("http://127.0.0.1:9800/verify", { otp }, {
                headers: {
                    'Content-Type': 'application/json'
                },
                withCredentials: true
            });
            if (response.status == 200) {
                navigate("/addpassword");
            }
            if (response.status == 204) {
                console.log(response.data.msg);
                setError(true);
            }
        } else {
            alert("Please enter a valid 4-digit OTP.");
        }
    };

    return (
        <Box
            sx={{
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                justifyContent: "center",
                width: "20vw",
                height: "30vh",
                padding: "16px",
                marginLeft: "35vw",
                backgroundColor: "#f5f5f5",
            }}
        >
            <Typography variant="h5"
                sx={{
                    color: "black"
                }}
                mb={2}>
                OTP Verification
            </Typography>
            <TextField
                label="Enter OTP"
                variant="outlined"
                fullWidth
                error={error}
                helperText={error ? "Please enter a valid 4-digit OTP." : ""}
                value={otp}
                onChange={handleOtpChange}
                sx={{
                    maxWidth: "200px",
                    marginBottom: "16px",
                    textAlign: "center",
                }}
                inputProps={{
                    inputMode: "numeric", // Opens numeric keypad on mobile
                    maxLength: 4, // Limits input to 4 characters
                    style: { textAlign: "center" }, // Centers the text
                }}
            />
            <Button
                variant="contained"
                color="success"
                onClick={handleVerify}
                sx={{
                    maxWidth: "200px",
                    width: "100%", // Ensures the button matches the width of the input field
                    marginTop: "8px",
                }}
            >
                Verify OTP
            </Button>
        </Box>
    );
}
