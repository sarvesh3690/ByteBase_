import React, { useEffect, useState } from "react";
import { Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Button, Paper } from "@mui/material";
import Sidebar from "./SideBar";
import axios from "axios";

function AssignmentsTable() {
  const [assignments, setAssignments] = useState([]);

  const fetchAssignments = async () => {
    try {
      const response = await axios.get("http://localhost:8080/assignment");
      if (response.status === 200) {
        setAssignments(response.data);
      }
    } catch (error) {
      console.error("Error fetching assignments:", error);
    }
  };

  useEffect(() => {
    fetchAssignments();

  }, []);

  return (
    <div className="app"><Sidebar />

      <div className="main-content">
        <TableContainer component={Paper} sx={{ marginTop: "20px", maxWidth: "800px" }}>
          <Table>
            <TableHead>
              <TableRow sx={{ backgroundColor: "#b22222" }}>
                <TableCell sx={{ color: "white", fontWeight: "bold" }}>ID</TableCell>
                <TableCell sx={{ color: "white", fontWeight: "bold" }}>Title</TableCell>
                <TableCell sx={{ color: "white", fontWeight: "bold" }}>Deadline</TableCell>
                <TableCell sx={{ color: "white", fontWeight: "bold" }}>Assignment</TableCell>
                <TableCell sx={{ color: "white", fontWeight: "bold" }}>Module Name</TableCell>
                <TableCell sx={{ color: "white", fontWeight: "bold" }}>Upload</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {assignments.map((assignment) => (
                <TableRow key={assignment.id}>
                  <TableCell>{assignment.id}</TableCell>
                  <TableCell>{assignment.title}</TableCell>
                  <TableCell>{assignment.deadline}</TableCell>
                  <TableCell>
                    <a
                      href={assignment.pdfFile.split('\\').pop()}
                      download={assignment.pdfFile.split('\\').pop()}
                    >
                      {assignment.pdfFile.split('\\').pop()} {/* Display only the file name */}
                    </a>
                  </TableCell>
                  <TableCell>{assignment.moduleName}</TableCell>
                  <TableCell>
                    <Button variant="contained" sx={{ backgroundColor: "#b22222", color: "white" }}>
                      Upload
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      </div>
    </div >
  );
}

export default AssignmentsTable;
