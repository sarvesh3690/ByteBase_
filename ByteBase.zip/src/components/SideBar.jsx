import React, { useState } from "react";
import "../styles/SideBar.css";
import { LinkContainer } from "react-router-bootstrap";
import { Dashboard } from "@mui/icons-material";
import { Link, useNavigate } from "react-router-dom";


function Sidebar({ setActiveTab }) {
  const [isOpen, setIsOpen] = useState(true);
  const navigate = useNavigate();

  const handleItemClick = (item) => {
    setActiveTab(item); // Update the active tab in the parent component
  };

  const handleLogOut = () =>{
    localStorage.removeItem("user");
    navigate("/");
  }

  return (
    <div className={`sidebar`}>
      
      <h2>Menu</h2>
      <ul>
        <Link to="/dashboard">
          <li>Dashboard</li>
        </Link>
        <Link to="/assignment">
          <li>Assignment</li>
        </Link>
        <Link to="/recordedsession">
          <li >Recorded Session</li>
        </Link>
        <Link to="/classwork">
          <li>ClassWork</li>
        </Link>
        <li >Profile</li>
        <Link to="/editor">
          <li>Editor</li>
        </Link>

        <li onClick={handleLogOut}>Logout</li>

      </ul>
    </div >
  );
}

export default Sidebar;
