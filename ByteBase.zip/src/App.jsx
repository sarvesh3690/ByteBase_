import { BrowserRouter } from "react-router-dom"
import Sidebar from "./components/SideBar"
import "./styles/App.css"
import { AppRouter } from "./components/AppRouter"
import { Layout } from "./components/Layout"

function App() {


  return (
    <BrowserRouter>

      <Layout>
        <AppRouter></AppRouter>
      </Layout>

    </BrowserRouter>

  )
}

export default App
